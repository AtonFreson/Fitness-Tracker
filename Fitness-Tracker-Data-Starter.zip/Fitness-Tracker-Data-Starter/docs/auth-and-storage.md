# Authentication and storage model

## Browser authentication
Fitness Tracker is a static GitHub Pages application. It uses a fine-grained GitHub personal access token entered by the user in the browser.

The tracker does not need an OAuth callback server, GitHub App, Cloudflare Worker, client secret, Google login, Twitch login, or other authentication service.

The login screen links directly to GitHub's fine-grained token creation form. GitHub supports pre-filling token details with URL query parameters, so the tracker pre-fills the configured resource owner, token name/description, no expiry, and `Contents: write`. GitHub still requires the user to choose the intended repository in its own UI.

For this project, select only `Fitness-Tracker-Data`.

## Token storage
When **Remember on this browser** is checked, the token is stored in browser local storage. When it is unchecked, it exists only in memory for the current page session.

The token is sent as a Bearer credential only to GitHub's API by the tracker. It is not committed to `Fitness-Tracker` or `Fitness-Tracker-Data`.

A separate token can be created on every device, so users do not need to copy an existing token between phones/computers. Revoking a token removes access but does not affect repository data.

## Permission boundary
Use a **fine-grained** PAT with:

```text
Resource owner:       the account that owns Fitness-Tracker-Data
Repository access:    Only select repositories → Fitness-Tracker-Data
Repository permission Contents: Read and write
```

`Contents: write` includes read access, which is needed to load existing event files as well as save new ones.

## Why the tracker does not use browser-only GitHub Device Flow
GitHub's normal REST API is usable cross-origin from browsers, but its OAuth/device-code token exchange endpoints are not CORS-enabled for this direct static-browser use. A browser-only implementation therefore fails before it can obtain the GitHub credential.

## Why Google or Twitch login does not replace the GitHub credential
Google Identity Services and Twitch both provide browser authentication options, but a Google/Twitch identity token cannot authorize access to a private GitHub repository. A backend would still need to hold a GitHub credential and map the external login to it. That adds another hosted service and secret store without removing the need for GitHub authorization somewhere in the architecture.

## Public Pages vs private data
`Fitness-Tracker` is public. Its `config.js` contains the GitHub username, private repository name, branch, and data-root path. Those are identifiers, not secrets.

The actual fitness records live in `Fitness-Tracker-Data`, which must remain private. The tracker reads repository metadata and refuses to save if the configured data repository is public.

## Append-only application behavior
Canonical writes are event files. The app does not normally update or delete an existing event file.

A save appends an `upsert_logs` event. A hide action appends a `delete_logs` tombstone. The current view is produced by replaying those events in order.

This gives two useful history layers:

- old application events remain present;
- Git also keeps commit history for those files.

It improves resistance to accidental overwrites/deletes, but an independent backup would still be needed to protect against destruction/loss of the entire GitHub repository or account.
