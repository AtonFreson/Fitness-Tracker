# Fitness Tracker Data

Keep this repository **private**. It stores the data for the public `Fitness-Tracker` GitHub Pages app.

## Data

Logs are stored as JSON arrays by month:

```text
data/events/2026-05.json
data/events/2026-06.json
```

Each log has a deterministic ID. Re-importing the same measurement/workout replaces that ID only when its data changed. Deleting a log removes it from the monthly file.

## Setup

### 1. Repositories

Create:

- `Fitness-Tracker` — **public**
- `Fitness-Tracker-Data` — **private**

Upload the tracker files to `Fitness-Tracker`. If starting from `Fitness-Tracker-Data-Starter.zip`, extract it and upload its contents to `Fitness-Tracker-Data`.

### 2. `config.js`

In the public repository, edit:

```js
export const CONFIG = {
  githubOwner: 'YOUR_GITHUB_USERNAME',
  githubRepo: 'Fitness-Tracker-Data',
  githubBranch: 'main',
  dataRoot: 'data',
  googleVisionApiKey: '',
};
```

Set `githubOwner` to the owner of the private data repository.

### 3. GitHub Pages

In `Fitness-Tracker` open **Settings → Pages** and use:

```text
Source: Deploy from a branch
Branch: main
Folder: /(root)
```

### 4. Google Cloud Vision

TANITA receipt scans use Cloud Vision OCR.

1. Open the [Google Cloud APIs & Services dashboard](https://console.cloud.google.com/apis/dashboard) and select/create a project.
2. Open [Google Cloud Billing](https://console.cloud.google.com/billing) and link billing to that project.
3. In **APIs & Services → Library**, enable **Cloud Vision API**.
4. In **APIs & Services → Credentials**, create an **API key**.
5. Edit the key and restrict it to **Cloud Vision API** only.
6. Set **Application restrictions → Websites** and add:

```text
https://YOUR_GITHUB_USERNAME.github.io
https://YOUR_GITHUB_USERNAME.github.io/*
```

7. Save the restrictions and put the key in `googleVisionApiKey` in public `config.js`.

Billing must be enabled even when usage is within Google's free allowance. Keep both the website and Cloud Vision API restrictions enabled because the browser key is part of the public site.

### 5. GitHub token

Create a fine-grained GitHub token with:

- **Repository access:** `Fitness-Tracker-Data` only
- **Contents:** Read and write

Put the generated `github_pat_...` value in `TRACKER_TOKEN.txt` as the only contents of the file and commit it to this private repository.

Open the tracker, copy the token from `TRACKER_TOKEN.txt`, paste it into the login screen, and connect.

## Imports

The tracker supports:

- TANITA DC-360 PDF/image scans
- ACCUNIQ reports
- Apple Health `export.xml`
- Apple Health export ZIPs

TANITA/ACCUNIQ values are reviewed before saving. Apple Health imports Traditional Strength Training workouts, including active energy and the heart-rate readings present in the export.

Full Apple Health exports can be imported repeatedly; unchanged workout IDs are not written again.

## Security

- Keep this repository private.
- Restrict the GitHub token to this repository with **Contents: Read and write**.
- Never put the GitHub token in the public repository or `config.js`.
- Keep the Google Vision key restricted to the GitHub Pages site and Cloud Vision API.

## Troubleshooting

For TANITA OCR errors, open **Extraction diagnostic text**. A successful Vision request shows `HTTP result: 200`.

For GitHub errors, check `config.js`, repository visibility, and the token's repository/Contents permissions.
