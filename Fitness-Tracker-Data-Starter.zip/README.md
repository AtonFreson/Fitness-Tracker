# Fitness Tracker Data

> **Keep this repository private.** It contains the data used by the public `Fitness-Tracker` GitHub Pages website.

This repository is the canonical data store for Fitness Tracker. The website itself lives in a public repository; imported Apple Health, TANITA and ACCUNIQ data is written here as normal private GitHub repository files.

Normal use does not require a server, Cloudflare Worker, GitHub App, OAuth callback, tracker password or moving a backup file between devices. A narrowly scoped fine-grained GitHub token is saved in `TRACKER_TOKEN.txt` in this private repository; on another device you sign in to GitHub normally, open that private file, copy the token, and paste it into the tracker.

## Sharing / duplicating the complete setup
Do **not** share this live repository after it contains personal data.

Use the public `Fitness-Tracker` repository instead:

1. Open `Fitness-Tracker` on GitHub.
2. Click **Code → Download ZIP**.
3. Share that downloaded ZIP.

The public ZIP contains the whole website source plus a clean `Fitness-Tracker-Data-Starter.zip` with these instructions and no saved health data. Someone who finds the public repository can use the same starter.

## Repository layout
Use these names unless you intentionally change `config.js`:

```text
Fitness-Tracker        PUBLIC   GitHub Pages website/source
Fitness-Tracker-Data   PRIVATE  health and fitness data
```

Saved events are appended below:

```text
data/
  events/
    2026/
      <timestamp>_<random-id>.json
    2027/
      ...
```

Each save creates another event file rather than rewriting one large database file. See [`docs/data-schema.md`](docs/data-schema.md).

# Initial setup

## 1. Create `Fitness-Tracker-Data`
On GitHub:

1. Click **+ → New repository**.
2. Set the repository name to `Fitness-Tracker-Data`.
3. Set visibility to **Private**.
4. Create it empty; GitHub does not need to add a README, `.gitignore`, or license.
5. Click **Create repository**.

If you are reading this from `Fitness-Tracker-Data-Starter.zip`, extract that ZIP first. In the new repository choose **Add file → Upload files** and upload the **contents of the extracted starter folder**, not the ZIP itself.

A clean starter should approximately contain:

```text
README.md
TRACKER_TOKEN.txt
docs/
data/
  events/
```

The starter intentionally contains no personal health records.

## 2. Create `Fitness-Tracker`
Create another repository:

1. Repository name: `Fitness-Tracker`.
2. Visibility: **Public**.
3. Create it empty.
4. Extract the public `Fitness-Tracker.zip` and upload its contents using **Add file → Upload files**.

The public repository should contain files such as:

```text
README.md
index.html
app.js
config.js
styles.css
src/
tests/
Fitness-Tracker-Data-Starter.zip
```

There is deliberately no required `.github` folder or `.nojekyll` file. This avoids GitHub's web uploader dropping hidden dot-files.

## 3. Configure the tracker
In the public `Fitness-Tracker` repository, edit `config.js`.

The important part is:

```js
export const CONFIG = {
  githubOwner: 'YOUR_GITHUB_USERNAME',
  githubRepo: 'Fitness-Tracker-Data',
  githubBranch: 'main',
  dataRoot: 'data',
  googleVisionApiKey: '',
};
```

Change only `YOUR_GITHUB_USERNAME` to the GitHub account that owns the private data repository. Normally leave the other values unchanged, then commit the edit.

### Optional but recommended: Google Cloud Vision OCR for TANITA
The tracker can read TANITA receipts locally with Tesseract, but Google Cloud Vision is substantially more reliable on faint thermal-printer scans. ACCUNIQ normally has an embedded PDF text layer, so this setting is mainly for TANITA.

The current Google Cloud console setup is:

1. Open the [Google Cloud APIs dashboard](https://console.cloud.google.com/apis/dashboard) and select or create the Google Cloud project you want to use for Fitness Tracker.
2. Open [Google Cloud Billing](https://console.cloud.google.com/billing), create/select a billing account if needed, and make sure it is **linked to the same Google Cloud project** you selected above. This is required for Cloud Vision requests to work. Cloud Vision currently includes the first 1,000 Document Text Detection units each month at no charge, but billing still has to be enabled on the project.
3. In the left sidebar, open **Library**, search for **Cloud Vision API**, and enable it.
4. Open **APIs & Services → Credentials**.
5. Click **+ Create credentials → API key**. You do **not** need to create an OAuth client, configure the OAuth consent screen, or bind this Cloud Vision key to a service account.
6. Open the API key to edit it. You can give it any descriptive name, such as `Fitness Tracker Document Scanner`.
7. In **APIs that can be accessed using this key**, set **Select API restrictions** so **Selected APIs** contains only **Cloud Vision API**.
8. In **Key restrictions → Application restrictions**, select **Websites**.
9. Under **Website restrictions**, press **Add** and add both of these entries, replacing the username if needed:

```text
https://YOUR_GITHUB_USERNAME.github.io
https://YOUR_GITHUB_USERNAME.github.io/*
```

For the original tracker deployment these are:

```text
https://atonfreson.github.io
https://atonfreson.github.io/*
```

If you use a custom GitHub Pages domain, add that domain instead/as well.
10. Press **Save**. Google currently notes that restriction changes may take up to about five minutes to take effect.
11. Return to the **Credentials** list. A correctly restricted key should show something like **HTTP referrers, 1 API** under Restrictions. Press **Show key** and copy the key value.
12. Put the key in the **public** `Fitness-Tracker/config.js` file:

```js
googleVisionApiKey: 'YOUR_GOOGLE_CLOUD_VISION_API_KEY',
```

13. Commit the change and wait for GitHub Pages to republish. Import a TANITA report and open **Extraction diagnostic text**. A working setup should show:

```text
Cloud Vision configured: yes
Cloud Vision request attempted: yes
HTTP result: 200
```

If Google rejects the request, the same diagnostic section includes the HTTP/Google error and the tracker automatically falls back to local OCR.

> **Important:** a static GitHub Pages site cannot keep a browser API key secret. The Google Vision key is therefore visible to users of the site. Use both the **Websites** application restriction and the **Cloud Vision API-only** API restriction, and do not reuse this key for other Google services. This is separate from the GitHub fine-grained access token: never put the GitHub token in public `config.js`.

## 4. Enable GitHub Pages
In the public `Fitness-Tracker` repository:

1. Open **Settings → Pages**.
2. Under **Build and deployment**, set **Source** to **Deploy from a branch**.
3. Select branch **main**.
4. Select folder **/(root)**.
5. Click **Save**.

Wait for GitHub Pages to publish the site. The Pages settings screen will show its URL when ready.

No Actions workflow is required for this project.

## 5. Create the repository access token once
The token is created only during the initial setup (or later if you deliberately rotate/revoke it).

Open the published Fitness Tracker site and use its **Create/replace token** link, or open GitHub's fine-grained personal access token settings manually. The tracker link pre-fills what GitHub allows it to pre-fill:

- token name;
- description;
- your GitHub account as resource owner;
- no expiration;
- **Contents: Read and write**.

Then on GitHub:

1. Under **Repository access**, choose **Only select repositories**.
2. Choose **`Fitness-Tracker-Data` only**.
3. Check that **Contents** says **Read and write**.
4. Click **Generate token**.
5. Copy the generated `github_pat_...` value. GitHub only shows the complete value at creation time.
6. Open `TRACKER_TOKEN.txt` in this **private** repository and edit it.
7. Make the token the **only contents of the file** — no label, quotes, JSON, spaces, or instructions. Commit the change.
8. Return to the tracker, paste the token, leave **Remember on this browser** enabled, and press **Connect GitHub**.

The tracker verifies the token and also checks that `Fitness-Tracker-Data` is actually private before opening the application.

> This token-file approach is an intentional convenience tradeoff. GitHub's general security guidance recommends not committing unencrypted credentials even to private repositories. If you use this setup, keep the token fine-grained and restricted to **only `Fitness-Tracker-Data` with Contents: Read and write**. Never reuse the token for other repositories or broader account permissions.

### Another phone or computer
You no longer create or move a separate token.

1. Open Fitness Tracker.
2. Press **Open saved token on GitHub**.
3. If necessary, sign in to GitHub normally.
4. GitHub opens this private repository's `TRACKER_TOKEN.txt`. Copy the complete file contents.
5. Return to Fitness Tracker, paste the token, and press **Connect GitHub**.

If **Remember on this browser** is enabled, that browser keeps a local cached copy for later visits. Clearing browser storage only means repeating the copy/paste step; it does not affect the data or the token file in GitHub.

### If a token stops working
Create a replacement fine-grained token using the same narrow permissions, replace the contents of `TRACKER_TOKEN.txt`, and revoke the old token in GitHub's token settings. Old token values may remain in Git history, so revoking the old token is important when rotating it.

Losing or revoking a token does **not** delete any tracker data. It only removes API access until a valid replacement is used.

# Normal use

## Uploading data
Use the main upload control. The tracker automatically determines the source.

Currently supported:

- TANITA DC-360 body-composition receipt PDF/image;
- ACCUNIQ body-composition report PDF/image;
- Apple Health `export.xml`;
- the original Apple Health export ZIP, uploaded directly without extracting it first;
- Apple Health Traditional Strength Training workouts, including heart-rate and active-energy summaries when those records are present.

For body-composition reports, review the extracted values before saving. Saving writes a new event to this private repository.

## Exporting Apple Health from iPhone
On iPhone:

1. Open **Health**.
2. Open your profile from the top-right.
3. Choose **Export All Health Data**.
4. Save/share the generated ZIP to Files.
5. Upload that ZIP directly to Fitness Tracker.

You do not need to extract `export.xml` yourself.

## TANITA / ACCUNIQ detection
The same upload button handles both body-composition sources.

TANITA Files-app scans may have little or no embedded PDF text, so the tracker can render the receipt, use OCR, retry enhanced regions, normalize common OCR errors, and then show the result for review.

ACCUNIQ reports often contain a usable text layer and can normally be parsed directly. The tracker keeps TANITA and ACCUNIQ as distinct source series rather than silently treating readings from the two machines as identical.

# Data safety
GitHub is the canonical copy. Clearing browser data, forgetting/revoking a token, changing phones, or breaking the public Pages site does not remove records already stored here.

Normal writes are deliberately non-destructive:

1. Every import creates a new event file.
2. A later correction/re-save creates a later event rather than rewriting the old event.
3. Hiding a record adds a tombstone event instead of deleting the original import.
4. Git commit history provides another recovery path.

This makes accidental loss during normal tracker use unlikely, but it is not an absolute backup guarantee. Deliberately deleting the entire repository/account or destroying its Git history can still remove data. An independent mirror can be added later if that level of disaster recovery is wanted.

# Security / privacy model
- `Fitness-Tracker` is public so it can be hosted with GitHub Pages on GitHub Free.
- `Fitness-Tracker-Data` stays private.
- Health data is readable JSON in the private repository; the tracker does not additionally encrypt it.
- The browser talks directly to `api.github.com` using a fine-grained GitHub personal access token.
- The token should be restricted to **`Fitness-Tracker-Data` only** with **Contents: Read and write**.
- `TRACKER_TOKEN.txt` in the private data repository contains the fine-grained token so it can be retrieved after signing in to GitHub on another device.
- If **Remember on this browser** is enabled, the same token is also cached in that browser's local storage for convenience.
- `config.js` is public and contains the GitHub repository settings plus, if enabled, a website-restricted Google Cloud Vision API key. The GitHub access token must never be put in the public repository or `config.js`.
- A Google Cloud Vision API key used by this static site is visible to browsers; restrict it to your GitHub Pages website/custom domain and to the Cloud Vision API only. Do not reuse it for other services.
- The tracker checks repository metadata and refuses to save if GitHub reports that the configured data repository is public.

See [`docs/auth-and-storage.md`](docs/auth-and-storage.md) for the technical notes.

# Why not Google/Twitch/GitHub OAuth?
Google and Twitch can authenticate a user to a static browser application, but that identity does not grant permission to read or write a private GitHub repository. To use either one here, another backend would still have to hold a GitHub credential and translate the Google/Twitch login into GitHub access.

GitHub's own Device Flow is also not suitable for this completely static browser-only implementation because GitHub's device-code/token exchange endpoints are not CORS-enabled for direct browser calls.

A fine-grained token therefore keeps this version to two GitHub repositories and no additional service. The token is created once during setup and saved in the private data repository so other devices can retrieve it through an ordinary GitHub login.

# Updating / sharing

## Sharing with another person
Use:

**`Fitness-Tracker` → Code → Download ZIP**

That GitHub-generated ZIP contains the public tracker source and a clean `Fitness-Tracker-Data-Starter.zip`. Its `TRACKER_TOKEN.txt` is empty. The other person creates their own public/private repositories and their own fine-grained token during setup; they should never use yours.

## Updating the tracker later
Application updates belong in `Fitness-Tracker`. Do not replace or recreate this private repository just to update the website.

If the data schema changes later, migrations should remain append-only where practical so old event history remains recoverable.

# Development / tests
Tests live in the public repository:

```bash
npm test
```

For local development, serve the public folder over HTTP because it uses ES modules:

```bash
python3 -m http.server 8000
```

Parsing can be tested without connecting GitHub. Live repository access requires a valid fine-grained token.

# Troubleshooting

## The tracker says `config.js` is incomplete
Edit `Fitness-Tracker/config.js` and replace `YOUR_GITHUB_USERNAME` with the owner of `Fitness-Tracker-Data`, then wait for Pages to republish the changed file.

## `Open saved token on GitHub` gives a 404 or access error
Check that `config.js` has the correct GitHub owner/repository name, that `TRACKER_TOKEN.txt` exists on the configured branch of `Fitness-Tracker-Data`, and that you are signed into a GitHub account that can open the private repository.

## The token creation page cannot see `Fitness-Tracker-Data`
Check that the resource owner is the GitHub account that owns the repository and that `Fitness-Tracker-Data` already exists under that account.

## The token is rejected / repository cannot be opened
Check that:

- `config.js` has the correct owner and repo name;
- the token's **Repository access** includes `Fitness-Tracker-Data`;
- the token has **Contents: Read and write**;
- `Fitness-Tracker-Data` is still private.

If uncertain, revoke the token and create a fresh one from the tracker login screen.

## Pages does not appear
Open `Fitness-Tracker` → **Settings → Pages** and check:

```text
Source: Deploy from a branch
Branch: main
Folder: /(root)
```

No `.github/workflows/deploy.yml` and no `.nojekyll` file are required.

## I cleared Safari/browser data
Open Fitness Tracker, press **Open saved token on GitHub**, sign in to GitHub if necessary, copy `TRACKER_TOKEN.txt`, paste it, and continue. The canonical records are still in the private repository.

## `NetworkError` / CORS error for `github.com/login/device/code`
That means an older Device Flow build is still being served. This version does not call GitHub's Device Flow endpoints. Make sure the current public files have replaced the older version and that Pages is serving the updated branch.
