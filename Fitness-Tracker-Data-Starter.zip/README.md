# Fitness Tracker Data

> **Keep this repository private.** It contains the data used by the public `Fitness-Tracker` GitHub Pages website.

This repository is the canonical data store for Fitness Tracker. The website itself lives in a public repository; imported Apple Health, TANITA and ACCUNIQ data is written here as normal private GitHub repository files.

Normal use does not require a server, Cloudflare Worker, GitHub App, OAuth callback, tracker password or moving a backup file between devices. A narrowly scoped fine-grained GitHub token is saved in `TRACKER_TOKEN.txt` in this private repository; on another device you sign in to GitHub normally, open that private file, copy the token, and paste it into the tracker.

## Sharing / duplicating the complete setup
Do **not** share this live repository after it contains personal data.

Use the public `Fitness-Tracker` repository instead:

1. Open `Fitness-Tracker` on GitHub.
2. Click **Code → Download ZIP**.
3. Share that downloaded ZIP.

The public ZIP contains the whole website source plus a clean `Fitness-Tracker-Data-Starter.zip` with these instructions and no saved health data. Someone who finds the public repository can use the same starter.

## Repository layout
Use these names unless you intentionally change `config.js`:

```text
Fitness-Tracker        PUBLIC   GitHub Pages website/source
Fitness-Tracker-Data   PRIVATE  health and fitness data
```

Saved events are appended below:

```text
data/
  events/
    2026/
      <timestamp>_<random-id>.json
    2027/
      ...
```

Each normal save creates another event file rather than rewriting one large database file. Re-imports skip unchanged deterministic log IDs. An explicit confirmed Delete action is the exception: it rewrites/removes matching records from the current branch. See [`docs/data-schema.md`](docs/data-schema.md).

# Initial setup

## 1. Create `Fitness-Tracker-Data`
On GitHub:

1. Click **+ → New repository**.
2. Set the repository name to `Fitness-Tracker-Data`.
3. Set visibility to **Private**.
4. Create it empty; GitHub does not need to add a README, `.gitignore`, or license.
5. Click **Create repository**.

If you are reading this from `Fitness-Tracker-Data-Starter.zip`, extract that ZIP first. In the new repository choose **Add file → Upload files** and upload the **contents of the extracted starter folder**, not the ZIP itself.

A clean starter should approximately contain:

```text
README.md
TRACKER_TOKEN.txt
docs/
data/
  events/
```

The starter intentionally contains no personal health records.

## 2. Create `Fitness-Tracker`
Create another repository:

1. Repository name: `Fitness-Tracker`.
2. Visibility: **Public**.
3. Create it empty.
4. Extract the public `Fitness-Tracker.zip` and upload its contents using **Add file → Upload files**.

The public repository should contain files such as:

```text
README.md
index.html
app.js
config.js
styles.css
src/
tests/
Fitness-Tracker-Data-Starter.zip
```

There is deliberately no required `.github` folder or `.nojekyll` file. This avoids GitHub's web uploader dropping hidden dot-files.

## 3. Configure the tracker
In the public `Fitness-Tracker` repository, edit `config.js`.

The important part is:

```js
export const CONFIG = {
  githubOwner: 'YOUR_GITHUB_USERNAME',
  githubRepo: 'Fitness-Tracker-Data',
  githubBranch: 'main',
  dataRoot: 'data',
  googleVisionApiKey: '',
};
```

Change `YOUR_GITHUB_USERNAME` to the GitHub account that owns the private data repository. Leave `googleVisionApiKey` blank for now; the Google Cloud Vision setup below explains how to create and restrict the key before adding it. Normally leave the repository, branch and data-root values unchanged, then commit the edit.

## 4. Enable GitHub Pages
In the public `Fitness-Tracker` repository:

1. Open **Settings → Pages**.
2. Under **Build and deployment**, set **Source** to **Deploy from a branch**.
3. Select branch **main**.
4. Select folder **/(root)**.
5. Click **Save**.

Wait for GitHub Pages to publish the site. The Pages settings screen will show its URL when ready.

No Actions workflow is required for this project.

## 5. Set up Google Cloud Vision for TANITA OCR
Google Cloud Vision is used as the primary OCR source for TANITA receipt scans because it is substantially more reliable on faint thermal-printer text than the browser-only fallback. The tracker can still fall back to local Tesseract OCR if Vision is unavailable.

### 5.1 Create/select a Google Cloud project and enable billing
1. Open the [Google Cloud APIs & Services dashboard](https://console.cloud.google.com/apis/dashboard).
2. At the top of the page, select the Google Cloud project you want to use for Fitness Tracker, or create one.
3. Open [Google Cloud Billing](https://console.cloud.google.com/billing).
4. Create/select a billing account if needed and link it to the **same project**.

Billing must be enabled for Cloud Vision requests to work. Google currently provides the first **1,000 Document Text Detection units per month at no charge**, but a billing account still has to be attached to the project.

### 5.2 Enable the Cloud Vision API
1. Return to **APIs & Services**.
2. Open **Library**.
3. Search for **Cloud Vision API**.
4. Open it and click **Enable**.

### 5.3 Create the API key
1. In **APIs & Services**, open **Credentials**.
2. Click **+ Create credentials → API key**.
3. Open the newly created key so you are on the **Edit API key** page.
4. Give it a recognizable name such as `Fitness Tracker Document Scanner`.

No OAuth consent screen, OAuth client ID or service-account binding is required for this Cloud Vision setup.

### 5.4 Restrict the key
On the **Edit API key** page:

1. Under **APIs that can be accessed using this key**, choose **Select API restrictions**.
2. Select **Cloud Vision API** so it is the only selected API.
3. Under **Application restrictions**, choose **Websites**.
4. Under **Website restrictions**, add both of these, replacing `YOUR_GITHUB_USERNAME` with the account that hosts the public tracker:

```text
https://YOUR_GITHUB_USERNAME.github.io
https://YOUR_GITHUB_USERNAME.github.io/*
```

5. Click **Save**.

The Credentials list should then show the key as restricted by **HTTP referrers** and **1 API**. Google notes that restriction changes can take several minutes to propagate.

### 5.5 Put the key in `config.js`
1. Return to **APIs & Services → Credentials**.
2. Use **Show key** for the restricted key and copy it.
3. In the public `Fitness-Tracker` repository, edit `config.js`.
4. Set:

```js
googleVisionApiKey: 'YOUR_GOOGLE_VISION_API_KEY',
```

5. Commit the edit and wait for GitHub Pages to republish.

Because Fitness Tracker is a static browser application, this API key is visible to visitors in the public site source. Treat it as a **restricted browser key, not a secret**: keep both the Website restriction and the **Cloud Vision API only** restriction in place. Never put the GitHub personal access token in `config.js`.

### 5.6 Verify Vision is actually being used
Import a TANITA receipt and open **Extraction diagnostic text**. A working setup should show lines similar to:

```text
Cloud Vision configured: yes
Cloud Vision request attempted: yes
HTTP result: 200
Cloud Vision outcome: request succeeded
```

If the request fails, the diagnostic text records the HTTP/error details and the tracker falls back to local OCR.

## 6. Create the repository access token once
The token is created only during the initial setup (or later if you deliberately rotate/revoke it).

Open the published Fitness Tracker site and use its **Create/replace token** link, or open GitHub's fine-grained personal access token settings manually. The tracker link pre-fills what GitHub allows it to pre-fill:

- token name;
- description;
- your GitHub account as resource owner;
- no expiration;
- **Contents: Read and write**.

Then on GitHub:

1. Under **Repository access**, choose **Only select repositories**.
2. Choose **`Fitness-Tracker-Data` only**.
3. Check that **Contents** says **Read and write**.
4. Click **Generate token**.
5. Copy the generated `github_pat_...` value. GitHub only shows the complete value at creation time.
6. Open `TRACKER_TOKEN.txt` in this **private** repository and edit it.
7. Make the token the **only contents of the file** — no label, quotes, JSON, spaces, or instructions. Commit the change.
8. Return to the tracker, paste the token, leave **Remember on this browser** enabled, and press **Connect GitHub**.

The tracker verifies the token and also checks that `Fitness-Tracker-Data` is actually private before opening the application.

> This token-file approach is an intentional convenience tradeoff. GitHub's general security guidance recommends not committing unencrypted credentials even to private repositories. If you use this setup, keep the token fine-grained and restricted to **only `Fitness-Tracker-Data` with Contents: Read and write**. Never reuse the token for other repositories or broader account permissions.

### Another phone or computer
You no longer create or move a separate token.

1. Open Fitness Tracker.
2. Press **Open saved token on GitHub**.
3. If necessary, sign in to GitHub normally.
4. GitHub opens this private repository's `TRACKER_TOKEN.txt`. Copy the complete file contents.
5. Return to Fitness Tracker, paste the token, and press **Connect GitHub**.

If **Remember on this browser** is enabled, that browser keeps a local cached copy for later visits. Clearing browser storage only means repeating the copy/paste step; it does not affect the data or the token file in GitHub.

### If a token stops working
Create a replacement fine-grained token using the same narrow permissions, replace the contents of `TRACKER_TOKEN.txt`, and revoke the old token in GitHub's token settings. Old token values may remain in Git history, so revoking the old token is important when rotating it.

Losing or revoking a token does **not** delete any tracker data. It only removes API access until a valid replacement is used.

# Normal use

## Uploading data
Use the main upload control. The tracker automatically determines the source.

Currently supported:

- TANITA DC-360 body-composition receipt PDF/image;
- ACCUNIQ body-composition report PDF/image;
- Apple Health `export.xml`;
- the original Apple Health export ZIP, uploaded directly without extracting it first;
- Apple Health Traditional Strength Training workouts, including every matched timestamped heart-rate reading plus heart-rate/active-energy summaries when those records are present.

For body-composition reports, review the extracted values before saving. Saving writes a new event to this private repository.

## Exporting Apple Health from iPhone
On iPhone:

1. Open **Health**.
2. Open your profile from the top-right.
3. Choose **Export All Health Data**.
4. Save/share the generated ZIP to Files.
5. Upload that ZIP directly to Fitness Tracker.

You do not need to extract `export.xml` yourself. Apple Health exports contain the full history, but the tracker uses deterministic workout IDs and skips unchanged records, so importing a newer full ZIP does not create duplicate current data or duplicate event writes.

### Automatic Apple Health sync
The GitHub Pages website cannot read the iPhone HealthKit store directly or pull the end-to-end-encrypted Health database from iCloud through a browser API. A future automatic-sync option would therefore need a small native iPhone companion app with HealthKit permission. That app could use HealthKit change/anchor queries to send only newly added or deleted samples instead of repeatedly exporting the full ZIP.

## TANITA / ACCUNIQ detection
The same upload button handles both body-composition sources.

TANITA Files-app scans may have little or no embedded PDF text, so the tracker renders the receipt and, when configured, sends document/crop images to Google Cloud Vision for OCR. The Vision word geometry is reconstructed into the receipt's visual rows before parsing. If Vision is unavailable or incomplete, the tracker can fall back to local Tesseract OCR and enhanced image passes before showing the result for review.

ACCUNIQ reports often contain a usable text layer and can normally be parsed directly. The tracker keeps TANITA and ACCUNIQ as distinct source series rather than silently treating readings from the two machines as identical.

# Data safety
GitHub is the canonical copy. Clearing browser data, forgetting/revoking a token, changing phones, or breaking the public Pages site does not remove records already stored here.

Normal saves are deliberately non-destructive:

1. A new or changed import creates a new event file.
2. Re-importing an unchanged deterministic record ID is skipped instead of writing a duplicate event.
3. A later correction to the same ID creates a later upsert event.
4. Git commit history provides another recovery path.

**Delete is deliberately different.** After confirmation, the tracker removes matching records from current event/legacy files instead of adding a tombstone. If a batch event contains other logs, the event file is rewritten with those peer logs intact; an emptied event file is removed. Older versions may still remain in Git history unless that history is separately rewritten.

This makes accidental loss during normal tracker use unlikely, but it is not an absolute backup guarantee. Deliberately deleting the entire repository/account or destroying its Git history can still remove data. An independent mirror can be added later if that level of disaster recovery is wanted.

# Security / privacy model
- `Fitness-Tracker` is public so it can be hosted with GitHub Pages on GitHub Free.
- `Fitness-Tracker-Data` stays private.
- Health data is readable JSON in the private repository; the tracker does not additionally encrypt it.
- The browser talks directly to `api.github.com` using a fine-grained GitHub personal access token.
- The token should be restricted to **`Fitness-Tracker-Data` only** with **Contents: Read and write**.
- `TRACKER_TOKEN.txt` in the private data repository contains the fine-grained token so it can be retrieved after signing in to GitHub on another device.
- If **Remember on this browser** is enabled, the same token is also cached in that browser's local storage for convenience.
- `config.js` is public. It contains the GitHub repository settings and may contain the Google Cloud Vision browser API key.
- The Vision key is therefore **not secret**; it must be restricted to the tracker website via HTTP referrers and restricted to **Cloud Vision API only**.
- The GitHub personal access token is different: it must never be put in the public repository or `config.js`.
- The tracker checks repository metadata and refuses to save if GitHub reports that the configured data repository is public.

See [`docs/auth-and-storage.md`](docs/auth-and-storage.md) for the technical notes.

# Why not Google/Twitch/GitHub OAuth?
Google and Twitch can authenticate a user to a static browser application, but that identity does not grant permission to read or write a private GitHub repository. To use either one here, another backend would still have to hold a GitHub credential and translate the Google/Twitch login into GitHub access.

GitHub's own Device Flow is also not suitable for this completely static browser-only implementation because GitHub's device-code/token exchange endpoints are not CORS-enabled for direct browser calls.

A fine-grained token therefore remains the simplest way for the browser to access the private GitHub data repository. Google Cloud Vision is a separate OCR service only; it does not authenticate the user to GitHub and does not replace the fine-grained GitHub token. The GitHub token is created once during setup and saved in the private data repository so other devices can retrieve it through an ordinary GitHub login.

# Updating / sharing

## Sharing with another person
Use:

**`Fitness-Tracker` → Code → Download ZIP**

That GitHub-generated ZIP contains the public tracker source and a clean `Fitness-Tracker-Data-Starter.zip`. Its `TRACKER_TOKEN.txt` is empty. The other person creates their own public/private repositories and their own fine-grained token during setup; they should never use yours.

## Updating the tracker later
Application updates belong in `Fitness-Tracker`. Do not replace or recreate this private repository just to update the website.

If the data schema changes later, migrations should remain append-only where practical so old event history remains recoverable.

# Development / tests
Tests live in the public repository:

```bash
npm test
```

For local development, serve the public folder over HTTP because it uses ES modules:

```bash
python3 -m http.server 8000
```

Parsing can be tested without connecting GitHub. Live repository access requires a valid fine-grained token.

# Troubleshooting

## The tracker says `config.js` is incomplete
Edit `Fitness-Tracker/config.js` and replace `YOUR_GITHUB_USERNAME` with the owner of `Fitness-Tracker-Data`, then wait for Pages to republish the changed file.

## `Open saved token on GitHub` gives a 404 or access error
Check that `config.js` has the correct GitHub owner/repository name, that `TRACKER_TOKEN.txt` exists on the configured branch of `Fitness-Tracker-Data`, and that you are signed into a GitHub account that can open the private repository.

## The token creation page cannot see `Fitness-Tracker-Data`
Check that the resource owner is the GitHub account that owns the repository and that `Fitness-Tracker-Data` already exists under that account.

## The token is rejected / repository cannot be opened
Check that:

- `config.js` has the correct owner and repo name;
- the token's **Repository access** includes `Fitness-Tracker-Data`;
- the token has **Contents: Read and write**;
- `Fitness-Tracker-Data` is still private.

If uncertain, revoke the token and create a fresh one from the tracker login screen.

## Pages does not appear
Open `Fitness-Tracker` → **Settings → Pages** and check:

```text
Source: Deploy from a branch
Branch: main
Folder: /(root)
```

No `.github/workflows/deploy.yml` and no `.nojekyll` file are required.

## I cleared Safari/browser data
Open Fitness Tracker, press **Open saved token on GitHub**, sign in to GitHub if necessary, copy `TRACKER_TOKEN.txt`, paste it, and continue. The canonical records are still in the private repository.

## Google Cloud Vision is not being used / returns an error
Open the TANITA import's **Extraction diagnostic text** first.

For a working Vision setup, check that it says:

```text
Cloud Vision configured: yes
Cloud Vision request attempted: yes
HTTP result: 200
```

If it does not:

- confirm billing is enabled and linked to the same Google Cloud project;
- confirm **Cloud Vision API** is enabled in **APIs & Services → Library**;
- confirm the API key's **API restriction** allows **Cloud Vision API** and no unrelated APIs;
- confirm **Application restrictions → Websites** includes both `https://YOUR_GITHUB_USERNAME.github.io` and `https://YOUR_GITHUB_USERNAME.github.io/*`;
- confirm `googleVisionApiKey` in the public `config.js` contains the restricted key;
- after changing key restrictions, allow several minutes for Google to apply them.

A Vision failure does not prevent TANITA import completely; the tracker should report the error in diagnostics and fall back to local OCR.

## `NetworkError` / CORS error for `github.com/login/device/code`
That means an older Device Flow build is still being served. This version does not call GitHub's Device Flow endpoints. Make sure the current public files have replaced the older version and that Pages is serving the updated branch.
