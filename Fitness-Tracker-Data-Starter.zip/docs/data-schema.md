# Data schema

## Canonical storage: event files with deduplicated saves
New/changed saves live below:

```text
data/events/<year>/<UTC timestamp>_<random id>.json
```

The filename timestamp is the time the tracker saved the event, not necessarily the time a measurement/workout happened.

### Upsert event

```json
{
  "schema_version": 1,
  "event_type": "upsert_logs",
  "created_at": "2030-01-02T03:04:05.678Z",
  "logs": []
}
```

Each element of `logs` is a logical tracker record. Reusing the same record `id` in a later upsert replaces the earlier version in the materialized/current view. If a newly imported record is byte-for-byte equivalent after canonical key ordering, the tracker skips writing it again.

### Legacy delete/hide event (read compatibility)

```json
{
  "schema_version": 1,
  "event_type": "delete_logs",
  "created_at": "2030-01-03T03:04:05.678Z",
  "ids": ["record-id"]
}
```

Older tracker versions created these tombstones, so the reader still supports them. The current UI no longer creates a tombstone when you press Delete. A confirmed Delete removes the target ID from matching current event/legacy files; batched event files are rewritten with unrelated peer logs preserved, and empty files are removed. Git commit history can still contain older versions.

## Body-composition record
Common fields:

```json
{
  "schema_version": 1,
  "id": "tanita:2030-01-01T12:34:00",
  "kind": "body_composition",
  "measured_at_local": "2030-01-01T12:34:00",
  "source": {
    "type": "tanita_receipt",
    "device": "TANITA DC-360",
    "filename": "..."
  },
  "metrics": {
    "weight_kg": 70.0,
    "fat_percent": 20.0,
    "fat_mass_kg": 14.0,
    "ffm_kg": 56.0,
    "muscle_mass_kg": 53.0
  }
}
```

Supported body-composition source types:

- `tanita_receipt`
- `accuniq_report`

The sources are intentionally kept separate because the analyzers use different hardware/methods and can have systematic differences.

TANITA records can additionally contain TBW, bone mass, BMR, metabolic age, visceral fat rating, BMI, desirable ranges, physique rating, and bioelectrical R/X data when available.

ACCUNIQ records can additionally contain body water, protein, minerals, BMR, TDE/TDEE, physical age, score, target/control values, printed reference ranges, and body-type classification.

Derived values are marked in extraction metadata rather than silently treated as directly printed measurements.

## Workout record
Apple Health workout records use fields such as:

```json
{
  "schema_version": 1,
  "id": "apple-health:strength:2030-01-01T18:00:00+08:00",
  "kind": "workout",
  "start_at": "...",
  "end_at": "...",
  "duration_minutes": 60,
  "active_energy_kcal": 300,
  "heart_rate_bpm": {
    "average_bpm": 120,
    "min_bpm": 80,
    "max_bpm": 165,
    "sample_count": 2,
    "samples": [
      { "at": "2030-01-01T18:00:05+08:00", "bpm": 118 },
      { "at": "2030-01-01T18:00:10+08:00", "bpm": 122 }
    ]
  },
  "source": {
    "type": "apple_health_export"
  }
}
```

The importer currently targets Apple Health Traditional Strength Training workouts. It keeps every matched heart-rate `Record` as a timestamped sample, while also retaining Apple's workout-level average/min/max when those statistics are present. Active-energy records are summarized for the workout interval. Deterministic workout IDs make full-export re-imports idempotent: unchanged records are not written again.

## Legacy compatibility
The reader can also recognize the previous mutable layout if it exists:

```text
data/body-composition.jsonl
data/workouts/<year>.jsonl
data/other.jsonl
```

Those files are treated as a baseline. New writes use `data/events/`.
