# Data schema

## Canonical storage: append-only events
New writes live below:

```text
data/events/<year>/<UTC timestamp>_<random id>.json
```

The filename timestamp is the time the tracker saved the event, not necessarily the time a measurement/workout happened.

### Upsert event

```json
{
  "schema_version": 1,
  "event_type": "upsert_logs",
  "created_at": "2030-01-02T03:04:05.678Z",
  "logs": []
}
```

Each element of `logs` is a logical tracker record. Reusing the same record `id` in a later upsert replaces the earlier version in the materialized/current view without modifying the original event file.

### Delete/hide event

```json
{
  "schema_version": 1,
  "event_type": "delete_logs",
  "created_at": "2030-01-03T03:04:05.678Z",
  "ids": ["record-id"]
}
```

A later upsert of the same ID restores it to the current view.

## Body-composition record
Common fields:

```json
{
  "schema_version": 1,
  "id": "tanita:2030-01-01T12:34:00",
  "kind": "body_composition",
  "measured_at_local": "2030-01-01T12:34:00",
  "source": {
    "type": "tanita_receipt",
    "device": "TANITA DC-360",
    "filename": "..."
  },
  "metrics": {
    "weight_kg": 70.0,
    "fat_percent": 20.0,
    "fat_mass_kg": 14.0,
    "ffm_kg": 56.0,
    "muscle_mass_kg": 53.0
  }
}
```

Supported body-composition source types:

- `tanita_receipt`
- `accuniq_report`

The sources are intentionally kept separate because the analyzers use different hardware/methods and can have systematic differences.

TANITA records can additionally contain TBW, bone mass, BMR, metabolic age, visceral fat rating, BMI, desirable ranges, physique rating, and bioelectrical R/X data when available.

ACCUNIQ records can additionally contain body water, protein, minerals, BMR, TDE/TDEE, physical age, score, target/control values, printed reference ranges, and body-type classification.

Derived values are marked in extraction metadata rather than silently treated as directly printed measurements.

## Workout record
Apple Health workout records use fields such as:

```json
{
  "schema_version": 1,
  "id": "apple-health-workout:...",
  "kind": "workout",
  "start_at": "...",
  "end_at": "...",
  "duration_minutes": 60,
  "active_energy_kcal": 300,
  "heart_rate_bpm": {
    "average_bpm": 120,
    "min_bpm": 80,
    "max_bpm": 165,
    "samples": 400
  },
  "source": {
    "type": "apple_health_export"
  }
}
```

The importer currently targets Apple Health Traditional Strength Training workouts and summarizes heart-rate/active-energy records that fall within each workout interval.

## Legacy compatibility
The reader can also recognize the previous mutable layout if it exists:

```text
data/body-composition.jsonl
data/workouts/<year>.jsonl
data/other.jsonl
```

Those files are treated as a baseline. New writes use `data/events/`.
