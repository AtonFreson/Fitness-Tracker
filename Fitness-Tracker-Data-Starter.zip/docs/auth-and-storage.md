# Authentication and storage model

## Browser authentication
Fitness Tracker is a static GitHub Pages application. It uses a fine-grained GitHub personal access token entered by the user in the browser.

The tracker does not need an OAuth callback server, GitHub App, Cloudflare Worker, client secret, Google login, or Twitch login. Google Cloud Vision is used only as an optional OCR service for TANITA receipts; it is not an authentication service.

During initial setup, create one fine-grained token restricted to `Fitness-Tracker-Data` with **Contents: Read and write**, then save that token as the only contents of `TRACKER_TOKEN.txt` in the private data repository.

On a new device, the tracker links directly to:

```text
https://github.com/<owner>/Fitness-Tracker-Data/blob/main/TRACKER_TOKEN.txt
```

The user signs in to GitHub normally, copies the private file contents, returns to the tracker, and pastes the token. This avoids creating a separate token for every browser while still requiring the user's normal GitHub account access to retrieve it.

## Token storage
`TRACKER_TOKEN.txt` is stored in the **private** `Fitness-Tracker-Data` repository. It must contain only the fine-grained PAT itself.

When **Remember on this browser** is checked, the same token is also stored in browser local storage. When it is unchecked, the browser keeps it only in memory for the current page session.

The tracker sends the token as a Bearer credential only to GitHub's API.

## Permission boundary
Use a **fine-grained** PAT with:

```text
Resource owner:       the account that owns Fitness-Tracker-Data
Repository access:    Only select repositories -> Fitness-Tracker-Data
Repository permission Contents: Read and write
```

Do not give this token access to other repositories or broader account permissions. The token is intended only to read and append files in the same private repository where it is stored.

## Deliberate security tradeoff
GitHub's general credential-security guidance recommends not committing unencrypted authentication tokens even to private repositories. This project deliberately trades that best practice for easier multi-device access.

The practical boundary is therefore the private GitHub repository/account itself: anyone who can read `Fitness-Tracker-Data` can also read `TRACKER_TOKEN.txt`. Because the token must be scoped only to that same repository, it should not provide access to unrelated repositories.

If `Fitness-Tracker-Data` is ever made public, shared with someone who should not have access, or otherwise exposed, immediately revoke the token and create a replacement after the repository is private again.

When rotating the token, replace `TRACKER_TOKEN.txt` and revoke the old token. Git history may retain old file contents, so rotation is not complete until the old token is revoked.

## Why the tracker does not use browser-only GitHub Device Flow
GitHub's normal REST API is usable cross-origin from browsers, but its OAuth/device-code token exchange endpoints are not CORS-enabled for this direct static-browser use. A browser-only implementation therefore fails before it can obtain the GitHub credential.

## Why Google or Twitch login does not replace the GitHub credential
Google Identity Services and Twitch both provide browser authentication options, but a Google/Twitch identity token cannot authorize access to a private GitHub repository. A backend would still need to hold a GitHub credential and map the external login to it. That adds another hosted service and secret store without removing the need for GitHub authorization somewhere in the architecture.

## Public Pages vs private data
`Fitness-Tracker` is public. Its `config.js` contains the GitHub username, private repository name, branch, data-root path, and may contain a Google Cloud Vision browser API key. The Vision key is not treated as a secret: it must be restricted to the tracker website by HTTP referrer and restricted to Cloud Vision API only.

The actual fitness records and `TRACKER_TOKEN.txt` live in `Fitness-Tracker-Data`, which must remain private. The GitHub token must never be placed in the public repository. The tracker reads repository metadata and refuses to save if the configured data repository is public.

## Event storage, deduplication and deletion
Normal saves use event files. A new or changed record appends an `upsert_logs` event, and the current view is produced by replaying those events in order. If an imported record has the same deterministic `id` and the same canonical content as the current record, the tracker skips the write; this is especially important because every Apple Health export ZIP contains the full export history.

Older tracker versions used `delete_logs` tombstone events for Hide. Those legacy tombstones are still understood when reading old data, but the current UI does not create new tombstones.

A confirmed **Delete** is intentionally destructive for the current branch: the tracker finds event/legacy files containing the selected ID, removes that record, rewrites batched files while preserving unrelated records, and deletes a file if it becomes empty. **Delete all current logs** uses the same mechanism after an additional confirmation.

Git commit history can still contain previous versions of rewritten/deleted files. Removing a log from current repository files therefore does not scrub it from historical Git commits. An independent backup would still be needed to protect against destruction/loss of the entire GitHub repository or account.
